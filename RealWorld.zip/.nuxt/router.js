import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _032af257 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _617ed34c = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _62d842c8 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _523d781c = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _f29cc7e0 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _1147cecc = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _3907bb69 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _032af257,
    children: [{
      path: "",
      component: _617ed34c,
      name: "home"
    }, {
      path: "/login",
      component: _62d842c8,
      name: "login"
    }, {
      path: "/register",
      component: _62d842c8,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _523d781c,
      name: "profile"
    }, {
      path: "/settings",
      component: _f29cc7e0,
      name: "settings"
    }, {
      path: "/editor",
      component: _1147cecc,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _3907bb69,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
